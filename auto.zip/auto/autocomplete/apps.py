from django.apps import AppConfig


class AutocompleteConfig(AppConfig):
    name = 'autocomplete'
